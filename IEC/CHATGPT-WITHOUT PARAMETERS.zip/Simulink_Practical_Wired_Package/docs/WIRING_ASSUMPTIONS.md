# Wiring assumptions and review points

The uploaded screenshots are the only source. The following list separates what is visible from what the builder had to interpret to create connected models.

## Cycloconverter (PDF page 1)

**Visible:** eight thyristor-like blocks, two AC sources, two controlled-switch-shaped blocks at the centre, pulse generator icons, one NOT gate, a load resistor, voltage measurement, RMS, Display, Scope and powergui.

**Builder interpretation:** two single-phase full-controlled bridges connected anti-parallel across a common load; each bridge receives one AC source. The two central controlled switches are represented by Ideal Switch/Breaker blocks and are placed in the two converter output paths. Four pulse channels fire diagonal SCR pairs; a complementary pulse controls the two interlock switches.

**Review before use:** the actual centre switch block type, which side of the output network they belong on, and the exact pulse/firing arrangement are not sufficiently legible. These are not claimed as exact.

## Single-phase inverter (PDF page 2)

**Visible:** four IGBT-like blocks, four separate diode blocks, DC-side source, pulse generator, NOT gate, passive elements, measurement and Scope.

**Builder interpretation:** conventional full-bridge H-bridge. Each diode is connected anti-parallel to one IGBT. Pulse and complementary NOT outputs drive opposite diagonal pairs. Two capacitors are placed in series across the DC link as a split-link pair.

**Review before use:** the image does not show every passive terminal clearly. Confirm the two capacitor connection and the load/measurement placement against any lab notes. Numerical gate parameters remain defaults.

## Three-phase rectifier (PDF page 3)

**Visible:** six thyristors in three legs, three AC source symbols, six pulse generators, a resistive load, measurement blocks, Constants marked 3 and 2, Mux, two Scopes and powergui.

**Builder interpretation:** six-pulse full-controlled bridge. Each phase source is connected to one leg midpoint; the three source return terminals are tied as a star neutral. Three upper SCRs share the positive DC rail and three lower SCRs share the negative rail. A series current sensor and shunt voltage sensor measure the output.

**Review before use:** exact source phase sequence and firing-delay angles are unreadable. The Pulse Generator defaults do not reproduce the screenshot's firing pattern until you edit them.

## Buck-Boost DC-DC (PDF page 4)

**Visible:** DC source, MOSFET-like switch, diode, one inductor, output capacitor, resistor load, Pulse Generator, current and voltage sensors, Displays/Scope and powergui.

**Builder interpretation:** source positive feeds the controlled switch; the switch node connects to an inductor to return and a diode to the output capacitor/load. This follows the visible ordering.

**Review before use:** the pictured topology looks like a boost stage even though the page title says Buck-Boost. The script intentionally follows the screenshot label and visible node arrangement, not a textbook circuit correction.

## Cuk DC-DC (PDF page 5)

**Visible:** DC source, controlled switch, diode, several inductor-shaped branches, series coupling capacitor, output capacitor, load resistor, Pulse Generator, measurement blocks and powergui.

**Builder interpretation:** input series inductor, a second shunt inductor at the switch node, series coupling capacitor, shunt diode, third series/output inductor, output capacitor and load.

**Review before use:** the middle shunt branch is visible as a coil but its precise purpose and wiring junction are not fully legible. It is included as an inductor because that matches the symbol.

## PID first and second order (PDF pages 7-8)

**Visible and used:** Step -> negative feedback Sum -> PID Controller -> Transfer Fcn; plant output returns to the negative Sum input; reference and output are fed to a Mux and Scope.

- First-order plant: `(s+1)/(10s+1)`.
- Second-order plant: `(s+1)/(s^2+4s+4)`.

**Not visible:** PID block gains/filter and Step time/initial/final values. Library defaults are retained.

## Manual PID (PDF page 9)

**Visible and used:** Step/error Sum, parallel proportional gain 5, integral gain 5 followed by Integrator, derivative gain 1 followed by Derivative, controller Sum, plant and negative feedback. Plant `(s^2+6s+10)/(s^3+7s+1)`.

**Not visible:** Step mask values and any derivative filter settings. The visible gain values are entered as shown.

## DC motor speed control (PDF page 12)

**Visible and used:** Constant 1750 speed reference, Constant 10 load torque, Sum, PID Controller, Controlled Voltage Source, DC Machine, field DC source, measurement bus selector, speed signal, Gain, Mux, Scope and powergui.

**Builder interpretation:** first DC Machine left/right terminal pair is treated as armature; second pair as field. Mechanical load torque enters the DC Machine TL input. Measurement bus output selects `wm`; a Gain block feeds back speed to the negative error input.

**Review before use:** verify that the generated DC Machine terminal mapping matches the labels A+, A-, F+, F- in the block mask. The field-source value, machine mask values, PID settings and feedback Gain are not visible.

## Parameter policy

No hidden numeric values are invented. All unshown source/machine/passive/switching values are left at the copied library block defaults. Set them from your lab record or instructor-provided values before simulating.
