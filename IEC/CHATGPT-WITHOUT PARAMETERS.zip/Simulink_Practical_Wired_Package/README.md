# Simulink Practical Recreation - Wired Builder Package

This package uses only the uploaded 12-page reference PDF. It contains MATLAB scripts that generate nine editable `.slx` models on the college PC. MATLAB/Simulink is not installed in this workspace, so I cannot execute the builder here or attach MATLAB-generated `.slx` files directly.

## Models generated

| # | Model | Builder output | Wiring status |
|---|---|---|---|
| 1 | Cycloconverter | `Cycloconverter.slx` | Connected dual-bridge interpretation; two unclear centre switches are labelled placeholders |
| 2 | Single-phase full-bridge inverter | `Single_Phase_Inverter.slx` | Connected H-bridge interpretation with 4 IGBTs and 4 antiparallel diodes |
| 3 | Three-phase full-bridge rectifier | `Three_Phase_Rectifier.slx` | Connected six-SCR bridge with three star-connected AC sources |
| 4 | Buck-Boost DC-DC | `Buck_Boost.slx` | Connected to the switching-node/inductor-shunt/diode-output topology visible in the screenshot |
| 5 | Cuk DC-DC | `Cuk.slx` | Connected Cuk-like topology; all three visible inductor-shaped branches are included |
| 6 | PID first order | `PID_First_Order.slx` | Fully connected feedback loop |
| 7 | PID second order | `PID_Second_Order.slx` | Fully connected feedback loop |
| 8 | Manual PID | `PID_Manual.slx` | Fully connected P/I/D structure and feedback loop |
| 9 | DC motor speed control | `DC_Motor_Speed_Control.slx` | Connected control/electrical structure; confirm DC Machine port order on the installed release |

## Important accuracy note

The PDFs show circuit drawings, not the parameter dialogs. The builder therefore does **not** enter guessed voltages, resistances, inductances, capacitances, switching periods, firing angles, machine nameplate values, or hidden PID gains. Those blocks retain their MATLAB library defaults so you can edit their masks manually.

A few power-circuit connections are not uniquely recoverable from the screenshots. These are called out in the model annotations and in `docs/WIRING_ASSUMPTIONS.md`. In particular:

- The cycloconverter's two central controlled-switch block types and exact gate timing are unclear. The builder uses generic Ideal Switch/Breaker blocks as explicitly marked placeholders.
- The inverter shows four IGBTs and four separate diodes, but some passive/load wiring is difficult to read. The connected H-bridge and split-link capacitors are an interpretation of the picture.
- The page labelled Buck-Boost visually resembles a boost-stage connection (switching node with shunt inductor and series diode to the output). The builder follows the visible drawing rather than changing it to a textbook buck-boost circuit.
- The Cuk page appears to show three inductor-shaped branches. All three are included; confirm the shunt branch against the instructor's actual diagram.
- The DC Machine's A+/A-/F+/F- port ordering can vary by block/library version. The builder assumes the two left/right connector pairs correspond to armature and field in that order; check the generated diagram once in MATLAB.

These are wired model drafts, not verified drop-in reproductions. Please inspect the annotations and electrical paths before submitting or running simulations.

## Compatibility requirement

The source screenshots contain `powergui` and Specialized Power Systems (SPS) components. This package's power-circuit builder targets the **legacy SPS library** (`powerlib` or `sps_lib`). MathWorks removed Specialized Power Systems from Simscape Electrical starting with MATLAB R2026a. If the college computer uses R2026a or later and does not have a separately installed SPS library, the six power/motor models will not build from this version of the script. See MathWorks' current note: https://www.mathworks.com/help/simscape-electrical/ug/upgrade-sps-models-to-use-simscape-blocks.html

## How to use on the college PC

1. Extract the ZIP completely.
2. Open MATLAB and set the Current Folder to the extracted `Simulink_Practical_Wired_Package` directory.
3. Run the compatibility check first:

   ```matlab
   run('matlab/check_environment.m')
   ```

4. If it reports the legacy SPS library is available, generate all nine models:

   ```matlab
   run('matlab/BUILD_ALL.m')
   ```

5. The `.slx` files are saved in the `output` folder. Open each model and enter the values from your lab record/instructor.

If the SPS library is not available, you can still create the three PID models separately:

```matlab
run('matlab/BUILD_PID_ONLY.m')
```

Do not attempt to simulate the power circuits before entering the missing electrical and switching parameters and checking the connections.

## Files

- `matlab/BUILD_ALL.m` - builds all nine models.
- `matlab/BUILD_PID_ONLY.m` - builds the three PID models without SPS.
- `matlab/build_pid_models.m` - PID diagram builder.
- `matlab/build_power_circuits.m` - connected power-electronics and DC motor builder.
- `matlab/check_environment.m` - identifies the MATLAB release and whether legacy SPS is available.
- `docs/WIRING_ASSUMPTIONS.md` - exactly which circuit assumptions need review.
- `docs/unknown_parameters.csv` - numerical values not visible in the PDF.
