% CHECK_ENVIRONMENT  Diagnose MATLAB/Simulink and the legacy SPS library.
fprintf('MATLAB release: %s\n',version('-release'));
fprintf('MATLAB version: %s\n',version);
try
    v=ver('simulink');
    if isempty(v), fprintf('Simulink: NOT DETECTED\n'); else, fprintf('Simulink: %s\n',v.Version); end
catch ME
    fprintf('Could not query Simulink: %s\n',ME.message);
end
try, fprintf('Simulink license: %d\n',license('test','Simulink')); catch, end
roots={'powerlib','powerlib_extras','sps_lib'}; found=false;
for k=1:numel(roots)
    try
        load_system(roots{k}); fprintf('Legacy SPS library available: %s\n',roots{k}); found=true;
    catch
        fprintf('Legacy SPS library not available: %s\n',roots{k});
    end
end
if found
    fprintf('\nResult: the nine-model builder can attempt all models.\n');
else
    fprintf(['\nResult: Simulink PID models can be built, but the six power-electronics ', ...
        'models need legacy SPS blocks. MathWorks removed SPS beginning with R2026a. ', ...
        'Do not run BUILD_ALL until the release/library situation is resolved.\n']);
end
fprintf('\nInstalled products:\n');
try
    p=ver;
    for k=1:numel(p), fprintf(' - %s %s\n',p(k).Name,p(k).Version); end
catch
end
