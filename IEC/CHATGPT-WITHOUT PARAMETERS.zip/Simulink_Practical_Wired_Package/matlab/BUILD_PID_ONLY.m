% BUILD_PID_ONLY Generate the three signal-flow PID models (no SPS needed).
packageRoot=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(packageRoot,'matlab'));
outputDir=fullfile(packageRoot,'output');
if ~exist(outputDir,'dir'), mkdir(outputDir); end
build_pid_models(outputDir);
fprintf('PID models saved to %s\n',outputDir);
