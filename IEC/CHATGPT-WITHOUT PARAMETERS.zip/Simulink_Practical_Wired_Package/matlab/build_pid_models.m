function build_pid_models(outputDir)
% BUILD_PID_MODELS Build the three signal-flow PID practicals from the PDF.
% Unreadable PID and Step values remain at the installed block defaults.

if nargin < 1 || isempty(outputDir), outputDir = fullfile(pwd,'output'); end
if ~exist(outputDir,'dir'), mkdir(outputDir); end
if ~license('test','Simulink'), error('A Simulink license is required.'); end

% Page 7 transfer function is visibly (s+1)/(10s+1).
buildClosedLoop(fullfile(outputDir,'PID_First_Order.slx'), ...
    'PID_First_Order','[1 1]','[10 1]',20, ...
    'Plant read from PDF: (s+1)/(10s+1). PID gains and Step mask values are not visible; defaults retained.');

% Page 8 transfer function is visibly (s+1)/(s^2+4s+4).
buildClosedLoop(fullfile(outputDir,'PID_Second_Order.slx'), ...
    'PID_Second_Order','[1 1]','[1 4 4]',20, ...
    'Plant read from PDF: (s+1)/(s^2+4s+4). PID gains and Step mask values are not visible; defaults retained.');

buildManual(fullfile(outputDir,'PID_Manual.slx'));
end

function buildClosedLoop(filePath,modelName,num,den,stopTime,note)
startModel(modelName,stopTime,'ode45');
add_block('simulink/Sources/Step',[modelName '/Step'],'Position',[35 135 65 165]);
add_block('simulink/Math Operations/Sum',[modelName '/Error_Sum'], ...
    'Inputs','+-','IconShape','round','Position',[120 132 150 168]);
add_block('simulink/Continuous/PID Controller',[modelName '/PID_Controller'], ...
    'Position',[205 135 265 165]);
add_block('simulink/Continuous/Transfer Fcn',[modelName '/Plant'], ...
    'Numerator',num,'Denominator',den,'Position',[315 125 405 175]);
add_block('simulink/Signal Routing/Mux',[modelName '/Reference_and_Output'], ...
    'Inputs','2','Position',[465 130 470 190]);
add_block('simulink/Sinks/Scope',[modelName '/Scope'],'Position',[540 140 575 180]);

% Reference branches to the error summing junction and Scope Mux.
add_line(modelName,'Step/1','Error_Sum/1','autorouting','on');
add_line(modelName,'Step/1','Reference_and_Output/1','autorouting','on');
add_line(modelName,'Error_Sum/1','PID_Controller/1','autorouting','on');
add_line(modelName,'PID_Controller/1','Plant/1','autorouting','on');
add_line(modelName,'Plant/1','Reference_and_Output/2','autorouting','on');
add_line(modelName,'Plant/1','Error_Sum/2','autorouting','on');
add_line(modelName,'Reference_and_Output/1','Scope/1','autorouting','on');
addNote(modelName,note,[30 35 900 80]);
finishModel(modelName,filePath);
end

function buildManual(filePath)
modelName='PID_Manual'; startModel(modelName,20,'ode45');
add_block('simulink/Sources/Step',[modelName '/Step'],'Position',[25 205 55 235]);
add_block('simulink/Math Operations/Sum',[modelName '/Error_Sum'], ...
    'Inputs','+-','IconShape','round','Position',[115 202 145 238]);
add_block('simulink/Math Operations/Gain',[modelName '/Kp_5'], ...
    'Gain','5','Position',[205 120 250 150]);
add_block('simulink/Math Operations/Gain',[modelName '/Ki_5'], ...
    'Gain','5','Position',[205 200 250 230]);
add_block('simulink/Continuous/Integrator',[modelName '/Integrator'], ...
    'Position',[290 195 325 235]);
add_block('simulink/Math Operations/Gain',[modelName '/Kd_1'], ...
    'Gain','1','Position',[205 280 250 310]);
add_block('simulink/Continuous/Derivative',[modelName '/Derivative'], ...
    'Position',[290 275 325 315]);
add_block('simulink/Math Operations/Sum',[modelName '/PID_Sum'], ...
    'Inputs','+++','IconShape','round','Position',[375 190 410 260]);
add_block('simulink/Continuous/Transfer Fcn',[modelName '/Plant'], ...
    'Numerator','[1 6 10]','Denominator','[1 0 7 1]','Position',[465 195 560 245]);
add_block('simulink/Signal Routing/Mux',[modelName '/Reference_and_Output'], ...
    'Inputs','2','Position',[625 190 630 250]);
add_block('simulink/Sinks/Scope',[modelName '/Scope'],'Position',[700 205 735 245]);

add_line(modelName,'Step/1','Error_Sum/1','autorouting','on');
add_line(modelName,'Step/1','Reference_and_Output/1','autorouting','on');
add_line(modelName,'Error_Sum/1','Kp_5/1','autorouting','on');
add_line(modelName,'Error_Sum/1','Ki_5/1','autorouting','on');
add_line(modelName,'Error_Sum/1','Kd_1/1','autorouting','on');
add_line(modelName,'Kp_5/1','PID_Sum/1','autorouting','on');
add_line(modelName,'Ki_5/1','Integrator/1','autorouting','on');
add_line(modelName,'Integrator/1','PID_Sum/2','autorouting','on');
add_line(modelName,'Kd_1/1','Derivative/1','autorouting','on');
add_line(modelName,'Derivative/1','PID_Sum/3','autorouting','on');
add_line(modelName,'PID_Sum/1','Plant/1','autorouting','on');
add_line(modelName,'Plant/1','Error_Sum/2','autorouting','on');
add_line(modelName,'Plant/1','Reference_and_Output/2','autorouting','on');
add_line(modelName,'Reference_and_Output/1','Scope/1','autorouting','on');
addNote(modelName,['Visible values: Kp=5, Ki=5, Kd=1; plant ', ...
    '(s^2+6s+10)/(s^3+7s+1). Step mask values remain at defaults.'],[25 25 900 70]);
finishModel(modelName,filePath);
end

function startModel(modelName,stopTime,solver)
if bdIsLoaded(modelName), close_system(modelName,0); end
load_system('simulink'); new_system(modelName); open_system(modelName);
set_param(modelName,'StopTime',num2str(stopTime),'Solver',solver);
end
function addNote(modelName,note,pos)
a=Simulink.Annotation(modelName,['SOURCE NOTE: ' note]);
try, a.Position=pos; catch, end
end
function finishModel(modelName,filePath)
set_param(modelName,'ZoomFactor','FitSystem'); save_system(modelName,filePath); close_system(modelName,0);
fprintf('Created: %s\n',filePath);
end
