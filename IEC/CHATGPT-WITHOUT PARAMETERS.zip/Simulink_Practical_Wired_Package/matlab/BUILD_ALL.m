% BUILD_ALL Build nine connected practical models from the supplied PDF.
% Run this script from the extracted package folder in MATLAB.
packageRoot=fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(packageRoot,'matlab'));
outputDir=fullfile(packageRoot,'output');
if ~exist(outputDir,'dir'), mkdir(outputDir); end

fprintf('\n=== MATLAB / Simulink compatibility check ===\n');
run(fullfile(packageRoot,'matlab','check_environment.m'));
if ~found
    error(['Legacy SPS blocks were not detected. The three PID models can still be ', ...
        'built with BUILD_PID_ONLY.m, but the six power/motor models need SPS.']);
end

fprintf('\n=== Building three PID control-system models ===\n');
build_pid_models(outputDir);

fprintf('\n=== Building six wired SPS power/motor models ===\n');
build_power_circuits(outputDir);

fprintf('\nAll nine builder routines completed. Output folder: %s\n',outputDir);
fprintf(['Review the source-note annotations in each .slx file. Numeric values hidden ', ...
    'in the PDF are not invented; blocks retain library defaults until you edit them.\n']);
