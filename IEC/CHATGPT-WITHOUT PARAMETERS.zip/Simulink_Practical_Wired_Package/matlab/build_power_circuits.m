function build_power_circuits(outputDir)
% BUILD_POWER_CIRCUITS Build connected Specialized Power Systems circuits.
% The source screenshots show powergui blocks and SPS-style components.
% Numeric mask values not visible in the PDF are intentionally NOT set.
% This builder requires the legacy powerlib/Specialized Power Systems library.

if nargin < 1 || isempty(outputDir), outputDir=fullfile(pwd,'output'); end
if ~exist(outputDir,'dir'), mkdir(outputDir); end
loadPowerLibrary();

buildCycloconverter(outputDir);
buildSinglePhaseInverter(outputDir);
buildThreePhaseRectifier(outputDir);
buildBuckBoost(outputDir);
buildCuk(outputDir);
buildDCMotor(outputDir);
end

%% ------------------------- Cycloconverter -------------------------------
function buildCycloconverter(outDir)
m='Cycloconverter'; startPowerModel(m,'0.5'); addPowergui(m,[35 25 115 65]);
% Two single-phase full-controlled bridges connected anti-parallel at the load.
% The two small central controlled-switch symbols in the screenshot are not
% identifiable by type, so generic Ideal Switches are used and explicitly noted.
addSPS(m,'AC_Source_Positive',{'AC Voltage Source'},[65 270 115 330]);
addSPS(m,'AC_Source_Negative',{'AC Voltage Source'},[65 520 115 580]);
for k=1:8
    x=245+mod(k-1,4)*150; y=200+floor((k-1)/4)*250;
    addSPS(m,sprintf('SCR_%d',k),{'Thyristor','Thyristor (Detailed)'},[x y x+70 y+100]);
end
addSPS(m,'Positive_Converter_Switch',{'Ideal Switch','Breaker'},[825 285 895 345]);
addSPS(m,'Negative_Converter_Switch',{'Ideal Switch','Breaker'},[825 490 895 550]);
addSPS(m,'Load_R',{'Series RLC Branch'},[1090 365 1160 435]); setBranch(m,'Load_R','R');
addSPS(m,'Load_Voltage_Measurement',{'Voltage Measurement'},[1190 455 1245 495]);
addSPS(m,'Output_RMS',{'RMS'},[1290 475 1350 515]);
addStd(m,'Display','simulink/Sinks/Display',[1390 475 1450 515]);
addStd(m,'Scope','simulink/Sinks/Scope',[1390 300 1450 350]);

% Four bridge devices per converter. Terminal pairs are left/right on SPS blocks.
% Positive bridge AC input terminals are AC_A and AC_B.
% AC source is connected across the two AC input nodes.
wire(m,'AC_Source_Positive','L', 'SCR_1','L'); wire(m,'AC_Source_Positive','R','SCR_2','L');
wire(m,'AC_Source_Positive','L','SCR_3','R'); wire(m,'AC_Source_Positive','R','SCR_4','R');
% SCR1/2 feed the positive DC rail; SCR3/4 return from the negative rail.
net(m,{{'SCR_1','R'},{'SCR_2','R'},{'Positive_Converter_Switch','L'}});
net(m,{{'SCR_3','L'},{'SCR_4','L'},{'SCR_5','R'},{'SCR_6','R'},{'Load_R','R'},{'Load_Voltage_Measurement','R'}});

% Negative converter has its own AC input and is cross-connected to the load.
wire(m,'AC_Source_Negative','L','SCR_5','L'); wire(m,'AC_Source_Negative','R','SCR_6','L');
wire(m,'AC_Source_Negative','L','SCR_7','R'); wire(m,'AC_Source_Negative','R','SCR_8','R');
net(m,{{'SCR_7','L'},{'SCR_8','L'},{'Negative_Converter_Switch','L'}});
% Positive load node is reached from either bridge through its interlock switch.
net(m,{{'Positive_Converter_Switch','R'},{'Negative_Converter_Switch','R'},{'Load_R','L'},{'Load_Voltage_Measurement','L'}});
% Voltage sensor is connected in parallel across the two output rails.
connectSignal(m,'Load_Voltage_Measurement',1,'Output_RMS',1);
connectSignal(m,'Output_RMS',1,'Display',1); connectSignal(m,'Load_Voltage_Measurement',1,'Scope',1);

% Four firing pulse channels fire diagonal SCR pairs. A complementary pulse
% drives the two interlock switches; all timings remain default for user entry.
for k=1:4
    b=sprintf('Gate_Pulse_%d',k); addStd(m,b,'simulink/Sources/Pulse Generator',[140 115+k*85 195 145+k*85]);
end
addStd(m,'Switch_Pulse','simulink/Sources/Pulse Generator',[690 120 745 150]);
addStd(m,'Switch_NOT','simulink/Logic and Bit Operations/Logical Operator',[770 140 820 180]);
set_param([m '/Switch_NOT'],'Operator','NOT');
connectSignal(m,'Gate_Pulse_1',1,'SCR_1',1); connectSignal(m,'Gate_Pulse_1',1,'SCR_4',1);
connectSignal(m,'Gate_Pulse_2',1,'SCR_2',1); connectSignal(m,'Gate_Pulse_2',1,'SCR_3',1);
connectSignal(m,'Gate_Pulse_3',1,'SCR_5',1); connectSignal(m,'Gate_Pulse_3',1,'SCR_8',1);
connectSignal(m,'Gate_Pulse_4',1,'SCR_6',1); connectSignal(m,'Gate_Pulse_4',1,'SCR_7',1);
connectSignal(m,'Switch_Pulse',1,'Switch_NOT',1);
connectSignal(m,'Switch_Pulse',1,'Positive_Converter_Switch',1);
connectSignal(m,'Switch_NOT',1,'Negative_Converter_Switch',1);

addNote(m,['Wired dual-bridge anti-parallel cycloconverter interpretation. ', ...
    'The two central switch symbols in the PDF are unclear; Ideal Switch/Breaker ', ...
    'is a labelled placeholder. Confirm their actual library type and the SCR ', ...
    'firing sequence before treating this as an exact replica. All numeric values ', ...
    'and pulse timings are factory defaults and must be entered from your lab data.'],[25 25 1450 85]);
finishPowerModel(m,fullfile(outDir,'Cycloconverter.slx'));
end

%% ---------------------- Single-phase inverter ---------------------------
function buildSinglePhaseInverter(outDir)
m='Single_Phase_Inverter'; startPowerModel(m,'0.5'); addPowergui(m,[35 25 115 65]);
addSPS(m,'DC_Source',{'DC Voltage Source'},[80 330 140 390]);
addSPS(m,'DC_Link_Series_R',{'Series RLC Branch'},[160 250 215 300]); setBranch(m,'DC_Link_Series_R','R');
addSPS(m,'DC_Link_C1',{'Series RLC Branch'},[205 245 255 295]); setBranch(m,'DC_Link_C1','C');
addSPS(m,'DC_Link_C2',{'Series RLC Branch'},[205 410 255 460]); setBranch(m,'DC_Link_C2','C');
% Four IGBTs and four separate antiparallel diodes, as visible on page 2.
addSPS(m,'IGBT_Upper_A',{'IGBT'},[420 185 485 255]);
addSPS(m,'IGBT_Lower_A',{'IGBT'},[420 410 485 480]);
addSPS(m,'IGBT_Upper_B',{'IGBT'},[760 185 825 255]);
addSPS(m,'IGBT_Lower_B',{'IGBT'},[760 410 825 480]);
addSPS(m,'Diode_Upper_A',{'Diode'},[530 185 595 255]);
addSPS(m,'Diode_Lower_A',{'Diode'},[530 410 595 480]);
addSPS(m,'Diode_Upper_B',{'Diode'},[870 185 935 255]);
addSPS(m,'Diode_Lower_B',{'Diode'},[870 410 935 480]);
addSPS(m,'Load_Current_Measurement',{'Current Measurement'},[1010 305 1065 345]);
addSPS(m,'Load_R',{'Series RLC Branch'},[1100 305 1170 345]); setBranch(m,'Load_R','R');
addSPS(m,'Load_Voltage_Measurement',{'Voltage Measurement'},[1210 370 1265 410]);
addStd(m,'Pulse_A','simulink/Sources/Pulse Generator',[300 95 360 125]);
addStd(m,'Pulse_NOT','simulink/Logic and Bit Operations/Logical Operator',[375 100 425 140]);
set_param([m '/Pulse_NOT'],'Operator','NOT');
addStd(m,'Output_Mux','simulink/Signal Routing/Mux',[1290 275 1295 355]); set_param([m '/Output_Mux'],'Inputs','2');
addStd(m,'DC_Bus_Voltage_Display','simulink/Sinks/Display',[235 535 295 575]);
addStd(m,'Load_Current_Display','simulink/Sinks/Display',[1090 475 1150 515]);
addStd(m,'Scope','simulink/Sinks/Scope',[1360 300 1420 350]);
addSPS(m,'DC_Voltage_Measurement',{'Voltage Measurement'},[155 520 210 560]);

% DC source feeds the positive DC rail through the visible series resistor.
wire(m,'DC_Source','L','DC_Link_Series_R','L');
net(m,{{'DC_Link_Series_R','R'},{'IGBT_Upper_A','L'},{'IGBT_Upper_B','L'},{'DC_Link_C1','L'},{'Diode_Upper_A','R'},{'Diode_Upper_B','R'}});
net(m,{{'DC_Link_C1','R'},{'DC_Link_C2','L'}});
net(m,{{'DC_Source','R'},{'IGBT_Lower_A','R'},{'IGBT_Lower_B','R'},{'DC_Link_C2','R'},{'Diode_Lower_A','L'},{'Diode_Lower_B','L'}});
% DC-side voltage sensor is wired directly across the DC source terminals.
wire(m,'DC_Voltage_Measurement','L','DC_Source','L');
wire(m,'DC_Voltage_Measurement','R','DC_Source','R');
% Bridge leg A midpoint and B midpoint.
net(m,{{'IGBT_Upper_A','R'},{'IGBT_Lower_A','L'},{'Diode_Upper_A','L'},{'Diode_Lower_A','R'},{'Load_Current_Measurement','L'}});
net(m,{{'IGBT_Upper_B','R'},{'IGBT_Lower_B','L'},{'Diode_Upper_B','L'},{'Diode_Lower_B','R'},{'Load_R','R'}});
% Diode terminals are connected opposite to each IGBT to form antiparallel paths.
% Output branch and voltage sensor.
wire(m,'Load_Current_Measurement','R','Load_R','L');
wire(m,'Load_Voltage_Measurement','L','Load_Current_Measurement','L');
wire(m,'Load_Voltage_Measurement','R','Load_R','R');
connectSignal(m,'Pulse_A',1,'IGBT_Upper_A',1);
connectSignal(m,'Pulse_A',1,'IGBT_Lower_B',1);
connectSignal(m,'Pulse_A',1,'Pulse_NOT',1);
connectSignal(m,'Pulse_NOT',1,'IGBT_Lower_A',1);
connectSignal(m,'Pulse_NOT',1,'IGBT_Upper_B',1);
connectSignal(m,'Pulse_A',1,'Output_Mux',1);
connectSignal(m,'Load_Voltage_Measurement',1,'Output_Mux',2);
connectSignal(m,'Output_Mux',1,'Scope',1);
connectSignal(m,'DC_Voltage_Measurement',1,'DC_Bus_Voltage_Display',1);
connectSignal(m,'Load_Current_Measurement',1,'Load_Current_Display',1);
addNote(m,['Four-switch H-bridge with separate antiparallel diodes, a DC-source series resistor, ', ...
    'and split DC-link capacitor pair. The screenshot supports the component count, but the exact ', ...
    'DC-link capacitor wiring and passive/load measurement detail are not fully ', ...
    'legible. This is a wired H-bridge interpretation; set all device, source, ', ...
    'load and pulse parameters manually.'],[25 25 1450 90]);
finishPowerModel(m,fullfile(outDir,'Single_Phase_Inverter.slx'));
end

%% ---------------------- Three-phase rectifier --------------------------
function buildThreePhaseRectifier(outDir)
m='Three_Phase_Rectifier'; startPowerModel(m,'1'); addPowergui(m,[25 25 105 65]);
for k=1:3
    y=165+k*115;
    addSPS(m,sprintf('Phase_Source_%d',k),{'AC Voltage Source'},[75 y 125 y+55]);
    addSPS(m,sprintf('Upper_SCR_%d',k),{'Thyristor'},[390 150+k*105 455 225+k*105]);
    addSPS(m,sprintf('Lower_SCR_%d',k),{'Thyristor'},[390 495+k*75 455 570+k*75]);
    addStd(m,sprintf('Upper_Gate_%d',k),'simulink/Sources/Pulse Generator',[250 155+k*105 305 185+k*105]);
    addStd(m,sprintf('Lower_Gate_%d',k),'simulink/Sources/Pulse Generator',[250 500+k*75 305 530+k*75]);
end
addSPS(m,'Load_R',{'Series RLC Branch'},[790 350 860 410]); setBranch(m,'Load_R','R');
addSPS(m,'Output_Current_Measurement',{'Current Measurement'},[690 350 745 390]);
addSPS(m,'Output_Voltage_Measurement',{'Voltage Measurement'},[900 445 955 485]);
addStd(m,'Mux','simulink/Signal Routing/Mux',[1100 330 1105 445]);
set_param([m '/Mux'],'Inputs','3');
addStd(m,'Scope','simulink/Sinks/Scope',[1190 365 1250 415]);
addStd(m,'Scope_2','simulink/Sinks/Scope',[1190 485 1250 535]);
addStd(m,'Scope_2_Mux','simulink/Signal Routing/Mux',[1100 480 1105 555]);
set_param([m '/Scope_2_Mux'],'Inputs','2');
addStd(m,'Constant_3','simulink/Sources/Constant',[995 175 1040 205]); set_param([m '/Constant_3'],'Value','3');
addStd(m,'Constant_2','simulink/Sources/Constant',[995 225 1040 255]); set_param([m '/Constant_2'],'Value','2');
addStd(m,'Display','simulink/Sinks/Display',[1100 190 1160 230]);

% AC sources are connected in star. Source R terminals are the common neutral.
for k=2:3, wire(m,'Phase_Source_1','R',sprintf('Phase_Source_%d',k),'R'); end
% Phase source terminal L goes to the midpoint of its upper/lower SCR pair.
for k=1:3
    wire(m,sprintf('Phase_Source_%d',k),'L',sprintf('Upper_SCR_%d',k),'L');
    wire(m,sprintf('Phase_Source_%d',k),'L',sprintf('Lower_SCR_%d',k),'R');
    connectSignal(m,sprintf('Upper_Gate_%d',k),1,sprintf('Upper_SCR_%d',k),1);
    connectSignal(m,sprintf('Lower_Gate_%d',k),1,sprintf('Lower_SCR_%d',k),1);
end
% Common DC rails from the six SCRs.
net(m,{{'Upper_SCR_1','R'},{'Upper_SCR_2','R'},{'Upper_SCR_3','R'},{'Output_Current_Measurement','L'}});
net(m,{{'Lower_SCR_1','L'},{'Lower_SCR_2','L'},{'Lower_SCR_3','L'},{'Load_R','R'}});
wire(m,'Output_Current_Measurement','R','Load_R','L');
wire(m,'Output_Voltage_Measurement','L','Output_Current_Measurement','L');
wire(m,'Output_Voltage_Measurement','R','Load_R','R');
connectSignal(m,'Output_Current_Measurement',1,'Mux',1);
connectSignal(m,'Output_Voltage_Measurement',1,'Mux',2);
connectSignal(m,'Constant_3',1,'Mux',3);
connectSignal(m,'Output_Voltage_Measurement',1,'Scope_2_Mux',1);
connectSignal(m,'Constant_2',1,'Scope_2_Mux',2);
connectSignal(m,'Scope_2_Mux',1,'Scope_2',1);
connectSignal(m,'Mux',1,'Scope',1);
connectSignal(m,'Constant_3',1,'Display',1);
addNote(m,['Six-SCR three-phase full bridge; three AC sources share a neutral; ', ...
    'upper and lower SCRs form the three phase legs. Firing pulse phase shifts ', ...
    'are not legible and remain at default Pulse Generator settings. The PDF ', ...
    'does not show source magnitude/frequency or load resistance; enter them manually.'],[25 25 1320 90]);
finishPowerModel(m,fullfile(outDir,'Three_Phase_Rectifier.slx'));
end

%% --------------------------- Buck-Boost ---------------------------------
function buildBuckBoost(outDir)
m='Buck_Boost'; startPowerModel(m,'2'); addPowergui(m,[25 25 105 65]);
addSPS(m,'Input_Source',{'DC Voltage Source'},[80 300 140 360]);
addSPS(m,'Input_Voltage_Measurement',{'Voltage Measurement'},[80 420 135 460]);
addSPS(m,'MOSFET_Switch',{'MOSFET'},[300 250 370 320]);
addSPS(m,'Inductor_L',{'Series RLC Branch'},[480 345 550 405]); setBranch(m,'Inductor_L','L');
addSPS(m,'Diode_D',{'Diode'},[650 250 715 315]);
addSPS(m,'Output_Current_Measurement',{'Current Measurement'},[830 250 890 295]);
addSPS(m,'Output_Capacitor',{'Series RLC Branch'},[1010 355 1080 415]); setBranch(m,'Output_Capacitor','C');
addSPS(m,'Load_R',{'Series RLC Branch'},[1160 355 1230 415]); setBranch(m,'Load_R','R');
addSPS(m,'Output_Voltage_Measurement',{'Voltage Measurement'},[1280 450 1340 490]);
addStd(m,'Gate_Pulse','simulink/Sources/Pulse Generator',[285 145 345 175]);
addStd(m,'Mux','simulink/Signal Routing/Mux',[1380 225 1385 335]); set_param([m '/Mux'],'Inputs','3');
addStd(m,'Scope','simulink/Sinks/Scope',[1470 255 1530 305]);
addStd(m,'Input_Display','simulink/Sinks/Display',[170 420 230 460]);
addStd(m,'Output_Display','simulink/Sinks/Display',[1380 470 1440 510]);

% This is connected in the same order as the visible page-4 drawing:
% source -> controlled switch -> switching node -> diode -> output;
% inductor shunts the switching node to the return rail.
wire(m,'Input_Source','L','MOSFET_Switch','L');
wire(m,'MOSFET_Switch','R','Diode_D','L');
wire(m,'MOSFET_Switch','R','Inductor_L','L');
net(m,{{'Input_Source','R'},{'Inductor_L','R'},{'Output_Capacitor','R'},{'Load_R','R'}});
wire(m,'Diode_D','R','Output_Current_Measurement','L');
net(m,{{'Output_Current_Measurement','R'},{'Output_Capacitor','L'},{'Load_R','L'}});
wire(m,'Output_Voltage_Measurement','L','Output_Current_Measurement','R');
wire(m,'Output_Voltage_Measurement','R','Input_Source','R');
wire(m,'Input_Voltage_Measurement','L','Input_Source','L');
wire(m,'Input_Voltage_Measurement','R','Input_Source','R');
connectSignal(m,'Gate_Pulse',1,'MOSFET_Switch',1);
connectSignal(m,'Input_Voltage_Measurement',1,'Input_Display',1);
connectSignal(m,'Input_Voltage_Measurement',1,'Mux',1);
connectSignal(m,'Output_Current_Measurement',1,'Mux',2);
connectSignal(m,'Output_Voltage_Measurement',1,'Mux',3);
connectSignal(m,'Output_Voltage_Measurement',1,'Output_Display',1);
connectSignal(m,'Mux',1,'Scope',1);
addNote(m,['Wired according to the visible page-4 topology. Note: the screenshot ', ...
    'label says Buck-Boost, but the visible source-switch-node/inductor-shunt/diode ', ...
    'output arrangement resembles a boost stage. It is reproduced as drawn, not ', ...
    're-engineered. Set source, L, C, R, switch and pulse parameters manually.'],[25 25 1530 90]);
finishPowerModel(m,fullfile(outDir,'Buck_Boost.slx'));
end

%% ------------------------------- Cuk ------------------------------------
function buildCuk(outDir)
m='Cuk'; startPowerModel(m,'2'); addPowergui(m,[25 25 105 65]);
addSPS(m,'Input_Source',{'DC Voltage Source'},[60 330 120 390]);
addSPS(m,'Input_Voltage_Measurement',{'Voltage Measurement'},[60 455 115 495]);
addSPS(m,'Input_Inductor_L1',{'Series RLC Branch'},[235 315 305 375]); setBranch(m,'Input_Inductor_L1','L');
addSPS(m,'Main_Switch',{'MOSFET','IGBT'},[420 215 490 285]);
addSPS(m,'Shunt_Inductor_L2',{'Series RLC Branch'},[565 405 635 465]); setBranch(m,'Shunt_Inductor_L2','L');
addSPS(m,'Transfer_Capacitor_C1',{'Series RLC Branch'},[675 315 745 375]); setBranch(m,'Transfer_Capacitor_C1','C');
addSPS(m,'Diode_D',{'Diode'},[835 215 900 280]);
addSPS(m,'Output_Inductor_L3',{'Series RLC Branch'},[1000 315 1070 375]); setBranch(m,'Output_Inductor_L3','L');
addSPS(m,'Output_Current_Measurement',{'Current Measurement'},[1150 315 1210 355]);
addSPS(m,'Output_Capacitor_C2',{'Series RLC Branch'},[1270 405 1340 465]); setBranch(m,'Output_Capacitor_C2','C');
addSPS(m,'Load_R',{'Series RLC Branch'},[1400 405 1470 465]); setBranch(m,'Load_R','R');
addSPS(m,'Output_Voltage_Measurement',{'Voltage Measurement'},[1515 490 1575 530]);
addStd(m,'Gate_Pulse','simulink/Sources/Pulse Generator',[405 125 465 155]);
addStd(m,'Mux','simulink/Signal Routing/Mux',[1630 255 1635 375]); set_param([m '/Mux'],'Inputs','3');
addStd(m,'Scope','simulink/Sinks/Scope',[1715 295 1775 345]);
addStd(m,'Output_Display','simulink/Sinks/Display',[1630 490 1690 530]);

% Visible series path: Vin -> L1 -> node A -> C1 -> node B -> L3 -> output.
% Switch and shunt inductor connect from node A to return; diode connects node B to return.
wire(m,'Input_Source','L','Input_Inductor_L1','L');
wire(m,'Input_Inductor_L1','R','Transfer_Capacitor_C1','L');
wire(m,'Input_Inductor_L1','R','Main_Switch','L');
wire(m,'Input_Inductor_L1','R','Shunt_Inductor_L2','L');
wire(m,'Transfer_Capacitor_C1','R','Output_Inductor_L3','L');
wire(m,'Transfer_Capacitor_C1','R','Diode_D','R');
wire(m,'Output_Inductor_L3','R','Output_Current_Measurement','L');
net(m,{{'Input_Source','R'},{'Main_Switch','R'},{'Shunt_Inductor_L2','R'}, ...
    {'Diode_D','L'},{'Output_Capacitor_C2','R'},{'Load_R','R'}});
net(m,{{'Output_Current_Measurement','R'},{'Output_Capacitor_C2','L'},{'Load_R','L'}});
wire(m,'Input_Voltage_Measurement','L','Input_Source','L');
wire(m,'Input_Voltage_Measurement','R','Input_Source','R');
wire(m,'Output_Voltage_Measurement','L','Output_Current_Measurement','R');
wire(m,'Output_Voltage_Measurement','R','Input_Source','R');
connectSignal(m,'Gate_Pulse',1,'Main_Switch',1);
connectSignal(m,'Input_Voltage_Measurement',1,'Mux',1);
connectSignal(m,'Output_Current_Measurement',1,'Mux',2);
connectSignal(m,'Output_Voltage_Measurement',1,'Mux',3);
connectSignal(m,'Output_Voltage_Measurement',1,'Output_Display',1);
connectSignal(m,'Mux',1,'Scope',1);
addNote(m,['Wired Cuk-like circuit following the visible page-5 components. The ', ...
    'screenshot appears to show three inductor branches (two in series plus one ', ...
    'shunt), so all three are included rather than silently removing one. Confirm ', ...
    'the exact shunt-inductor branch against your instructor diagram. Numeric ', ...
    'values and pulse parameters remain at defaults for manual entry.'],[25 25 1775 95]);
finishPowerModel(m,fullfile(outDir,'Cuk.slx'));
end

%% ------------------------- DC motor speed control ----------------------
function buildDCMotor(outDir)
m='DC_Motor_Speed_Control'; startPowerModel(m,'10'); addPowergui(m,[25 25 105 65]);
addStd(m,'Speed_Reference_1750','simulink/Sources/Constant',[90 300 145 330]);
set_param([m '/Speed_Reference_1750'],'Value','1750');
addStd(m,'Load_Torque_10','simulink/Sources/Constant',[500 145 540 175]);
set_param([m '/Load_Torque_10'],'Value','10');
addStd(m,'Speed_Error_Sum','simulink/Math Operations/Sum',[235 300 270 345]);
set_param([m '/Speed_Error_Sum'],'Inputs','+-');
addStd(m,'PID_Controller','simulink/Continuous/PID Controller',[335 305 395 340]);
addSPS(m,'Controlled_Voltage_Source',{'Controlled Voltage Source'},[475 330 545 390]);
addSPS(m,'DC_Machine',{'DC Machine'},[725 250 865 430]);
addSPS(m,'Field_DC_Source',{'DC Voltage Source'},[640 500 700 550]);
addStd(m,'Machine_Measurement_Bus_Selector','simulink/Signal Routing/Bus Selector',[930 370 985 420]);
addStd(m,'Speed_Feedback_Gain','simulink/Math Operations/Gain',[535 405 585 445]);
addStd(m,'Reference_and_Speed_Mux','simulink/Signal Routing/Mux',[390 555 395 625]);
set_param([m '/Reference_and_Speed_Mux'],'Inputs','2');
addStd(m,'Scope','simulink/Sinks/Scope',[495 570 555 620]);

% Electrical connections follow visible DC motor ports A+, A-, F+, F-.
% Machine LConn/RConn pairs 1 and 2 are expected to be armature and field.
wire(m,'Controlled_Voltage_Source','L','DC_Machine','L1');
wire(m,'Controlled_Voltage_Source','R','DC_Machine','R1');
wire(m,'Field_DC_Source','L','DC_Machine','L2');
wire(m,'Field_DC_Source','R','DC_Machine','R2');
connectSignal(m,'Load_Torque_10',1,'DC_Machine',1);
connectSignal(m,'Speed_Reference_1750',1,'Speed_Error_Sum',1);
connectSignal(m,'Speed_Error_Sum',1,'PID_Controller',1);
connectSignal(m,'PID_Controller',1,'Controlled_Voltage_Source',1);
connectSignal(m,'DC_Machine',1,'Machine_Measurement_Bus_Selector',1);
% The bus selector's output list is set to wm (machine speed).
try, set_param([m '/Machine_Measurement_Bus_Selector'],'OutputSignals','wm'); catch, end
connectSignal(m,'Machine_Measurement_Bus_Selector',1,'Speed_Feedback_Gain',1);
connectSignal(m,'Speed_Feedback_Gain',1,'Speed_Error_Sum',2);
connectSignal(m,'Speed_Reference_1750',1,'Reference_and_Speed_Mux',1);
connectSignal(m,'Machine_Measurement_Bus_Selector',1,'Reference_and_Speed_Mux',2);
connectSignal(m,'Reference_and_Speed_Mux',1,'Scope',1);
addNote(m,['DC Machine closed-loop speed control. Visible constants: reference 1750 ', ...
    'and load torque TL=10. Controller gains, feedback Gain (-K-), machine ', ...
    'nameplate values and field supply value are not readable and remain at block ', ...
    'defaults. Check the DC Machine port order on your MATLAB release; if its mask ', ...
    'uses a different port ordering, adjust the four armature/field connections.'],[25 25 1450 95]);
finishPowerModel(m,fullfile(outDir,'DC_Motor_Speed_Control.slx'));
end

%% -------------------------- Shared utilities ----------------------------
function loadPowerLibrary()
roots={'powerlib','powerlib_extras','sps_lib'}; found=false;
for k=1:numel(roots)
    try, load_system(roots{k}); found=true; break; catch, end
end
if ~found
    error(['Legacy Specialized Power Systems library was not found. The source PDF uses ', ...
        'powergui/SPS-style blocks. MathWorks removed Specialized Power Systems ', ...
        'from Simscape Electrical starting in R2026a; use a pre-R2026a MATLAB release ', ...
        'or migrate the builder to current Simscape Electrical blocks.']);
end
end

function startPowerModel(modelName,stopTime)
if bdIsLoaded(modelName), close_system(modelName,0); end
load_system('simulink'); new_system(modelName); open_system(modelName);
set_param(modelName,'StopTime',stopTime,'Solver','ode23tb');
end

function addPowergui(modelName,pos)
addSPS(modelName,'powergui',{'powergui'},pos);
try, set_param([modelName '/powergui'],'SimulationMode','Continuous'); catch, end
end

function addSPS(modelName,blockName,candidates,pos)
source=findSPSBlock(candidates);
if isempty(source)
    error('Could not find required Specialized Power Systems block "%s". Legacy SPS may be unavailable in this MATLAB release.',blockName);
end
add_block(source,[modelName '/' blockName],'Position',pos);
end

function addStd(modelName,blockName,source,pos)
add_block(source,[modelName '/' blockName],'Position',pos);
end

function src=findSPSBlock(candidates)
src=''; roots={'powerlib','powerlib_extras','sps_lib'};
for r=1:numel(roots)
    root=roots{r};
    try, if ~bdIsLoaded(root), load_system(root); end, catch, continue; end
    for c=1:numel(candidates)
        try
            hits=find_system(root,'SearchDepth',Inf,'LookUnderMasks','all', ...
                'FollowLinks','on','Type','Block','Name',candidates{c});
            for h=1:numel(hits)
                if ~strcmp(hits{h},root), src=hits{h}; return; end
            end
        catch
        end
    end
end
end

function setBranch(modelName,blockName,branchType)
% Set only the element category (R/L/C); leave the numeric mask values untouched.
try, set_param([modelName '/' blockName],'BranchType',branchType); catch ME
    warning('Could not set %s branch type on %s: %s',branchType,blockName,ME.message);
end
end

function wire(modelName,blockA,portA,blockB,portB)
% Connect Specialized Power Systems conserving terminals. Port tokens are
% L/R for 1-port-per-side blocks, or L1/R1 etc. for multi-terminal machines.
a=terminalHandle([modelName '/' blockA],portA);
b=terminalHandle([modelName '/' blockB],portB);
try
    add_line(modelName,a,b,'autorouting','on');
catch ME
    error('Electrical wiring failed: %s.%s -> %s.%s. MATLAB reported: %s', ...
        blockA,portA,blockB,portB,ME.message);
end
end

function h=terminalHandle(blockPath,token)
p=get_param(blockPath,'PortHandles');
if strcmp(token(1),'L') || strcmp(token(1),'R')
    side=token(1); digits=token(2:end); if isempty(digits), idx=1; else, idx=str2double(digits); end
    field=[side 'Conn'];
    if ~isfield(p,field) || numel(p.(field))<idx
        error('Port %s not found on %s. Port fields are %s',token,blockPath,strjoin(fieldnames(p),', '));
    end
    ports=p.(field); h=ports(idx);
else
    error('Unsupported conserving-port token %s',token);
end
end

function net(modelName,refs)
% Join several terminals into one electrical node. refs is {{block,port},...}.
first=refs{1};
for k=2:numel(refs)
    current=refs{k};
    wire(modelName,first{1},first{2},current{1},current{2});
end
end

function connectSignal(modelName,sourceBlock,sourcePort,destBlock,destPort)
% Standard Simulink control/signal connection, including signal branching.
from=sprintf('%s/%d',sourceBlock,sourcePort); to=sprintf('%s/%d',destBlock,destPort);
try, add_line(modelName,from,to,'autorouting','on');
catch ME, error('Signal wiring failed: %s -> %s: %s',from,to,ME.message); end
end

function addNote(modelName,note,pos)
a=Simulink.Annotation(modelName,['SOURCE / PARAMETER NOTE: ' note]);
try, a.Position=pos; catch, end
end

function finishPowerModel(modelName,filePath)
set_param(modelName,'ZoomFactor','FitSystem'); save_system(modelName,filePath); close_system(modelName,0);
fprintf('Created wired model: %s\n',filePath);
end
